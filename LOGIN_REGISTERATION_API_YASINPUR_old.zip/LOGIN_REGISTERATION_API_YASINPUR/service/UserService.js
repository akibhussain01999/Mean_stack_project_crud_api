var pool = require("../lib/config");

//encryption with adduserinfo

var adduserdata = (userinfodata) => {
  return new Promise((resolve, reject) => {
    adduserinfo(userinfodata.companyinfodata).then((result) => {
      encryptionService
        .encryptData(userinfodata.companyinfodata)
        .then((companyinfodata) => {
          resolve({ message: "success" });
        })
        .catch((err) => {
          reject(err);
        });
    });
  });
};

var adduserinfo = (companyinfodata) => {
  return new Promise((resolve, reject) => {
    pool
      .query(
        'INSERT INTO userinfo("fname","lname","email","password","mobile","created_by","updated_by","updated_at","created_at")VALUES($1,$2,$3,$4,$5,$6,$7,Now(),Now())',
        [
          companyinfodata.fname,
          companyinfodata.lname,
          companyinfodata.email,
          companyinfodata.password,
          companyinfodata.mobile,
          companyinfodata.created_by,
          companyinfodata.updated_by,
          companyinfodata.userinfodata,
        ]
      )
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //register user
// var adduserdata = (
//   fname,
//   lname,
//   email,
//   password,
//   mobile,
//   created_by,
//   updated_by
// ) => {
//   return new Promise((resolve, reject) => {
//     pool
//       .query(
//         'INSERT INTO userinfo("fname","lname","email","password","mobile","created_by","updated_by","updated_at","created_at")VALUES($1,$2,$3,$4,$5,$6,$7,Now(),Now())',
//         [fname, lname, email, password, mobile, created_by, updated_by]
//       )
//       .then((result) => {
//         resolve(result.rows);
//       })
//       .catch((err) => {
//         reject(err);
//       });
//   });
// };

// //check user exist or not

var IsuserExists = (email) => {
  return new Promise((resolve, reject) => {
    pool
      .query('select "un".* from userinfo un where email=$1', [email])
      .then((result) => {
        if (result.rows.length != 0) {
          reject({ message: "user" + email + "alrady exist" });
        } else {
          resolve({ message: "success" });
        }
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //show user list

var getuserdatainfo = (Page_no) => {
  Page_size = 50;
  Page_start = Page_no * Page_size;
  return new Promise((resolve, reject) => {
    pool
      .query(
        'SELECT userinfo."fname",userinfo."lname",userinfo."email" ,count(*) OVER() AS total_records from userinfo order by userinfo."id" limit $1 offset $2',
        [Page_size, Page_start]
      )
      .then((result) => {
        console.log(result);
        resolve(result.rows);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //show user list by id
var getuserdataByid = (id) => {
  return new Promise((resolve, reject) => {
    pool
      .query('select "un".* from userinfo un where id=$1', [id])
      .then((result) => {
        console.log(result);
        resolve(result.rows);
      })

      .catch((err) => {
        reject(err);
      });
  });
};

var updateuserlist = (fname, lname, email, password) => {
  return new promise((resolve, reject) => {
    pool
      .query(
        'update userinfo  set "fname"=$1,"lname"=$2,"email"=$3,"password"=$4 where id= $5;',
        [fname, lname, email, password]
      )
      .than((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //delte user list

module.exports.deleteuser = (id) => {
  return new promise((resolve, reject) => {
    pool
      .query("delete from usermaster where id=$1;", [id])
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

module.exports = {
  getuserdataByid: getuserdataByid,
  getuserdatainfo: getuserdatainfo,
  // adduserdata: adduserdata,
  adduserdata: adduserdata,
  IsuserExists: IsuserExists,
  updateuserlist: updateuserlist,
};
