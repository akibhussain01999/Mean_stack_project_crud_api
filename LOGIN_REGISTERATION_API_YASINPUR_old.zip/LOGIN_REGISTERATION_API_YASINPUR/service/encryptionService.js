var bcrypt = require("bcrypt-nodejs");
var crypto = require("crypto");
var algorithm = "aes-256-ctr";
var password = "nishant";

var encrypt = (dataArray, callback) => {
  let resultArray = [];
  let nextIndex = 0;
  //dataArray.map((data, index) => {
  console.log(dataArray);
  for (var i = 0; i < dataArray.length + 1; i++) {
    if (dataArray.length == i) {
      callback(resultArray);
    } else {
      encryptJson(dataArray[i], (result) => {
        resultArray.push(result);
      });
    }
    //});
  }
};

var decrypt = (dataArray, callback) => {
  let resultArray = [];
  let nextIndex = 0;
  //dataArray.map((data, index) => {
  for (var i = 0; i < dataArray.length + 1; i++) {
    if (dataArray.length == i) {
      callback(resultArray);
    } else {
      decryptJson(dataArray[i], (result) => {
        resultArray.push(result);
      });
    }

    //});
  }
};

var decryptSingleValue = (value, callback) => {
  var cipher = crypto.createCipher(algorithm, password);
  var dec = decipher.update(data[key], "hex", "utf8");
  dec += decipher.final("utf8");
  callback(dec);
};

var encryptJson = (data, callback) => {
  var index = 0;
  let resultJson = {};
  var crypted = null;
  //let iv = crypto.randomBytes(parseInt(process.env.IV_LENGTH));
  for (var key in data) {
    if (
      key == "CIN" ||
      key == "factoryStuffingLicNo" ||
      key == "GSTNo" ||
      key == "IEC" ||
      key == "address" ||
      key == "city" ||
      key == "landmark" ||
      key == "state" ||
      key == "zip" ||
      key == "zipcode" ||
      key == "fName" ||
      key == "lName" ||
      key == "contactNo" ||
      key == "designation" ||
      key == "searchString" ||
      key == "gstno" ||
      key == "mobileNo"
    ) {
      var cipher = crypto.createCipher(
        algorithm,
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
      );
      if (data.hasOwnProperty(key)) {
        //console.log(data[key]);
        if (data[key] != null)
          //resultJson[key] =  bcrypt.hashSync(data[key], null, null);
          //resultJson[key] = crypto.pbkdf2Sync(data[key],"test", 1000, 64).toString('hex');

          crypted = cipher.update(data[key], "utf8", "hex");
        crypted += cipher.final("hex");
        resultJson[key] = crypted;
        crypted = null;

        /* let cipher = crypto.createCipheriv('aes-256-ctr', new Buffer(process.env.ENCRYPTION_KEY), iv);
             let encrypted = cipher.update(data[key]);
 
             encrypted = Buffer.concat([encrypted, cipher.final()]);
 
             //return iv.toString('hex') + ':' + encrypted.toString('hex');
             resultJson[key] = encrypted.toString('hex');*/
      }
    } else {
      resultJson[key] = data[key];
    }
    if (++index == Object.keys(data).length) {
      // resultJson.iv = iv.toString('hex');
      callback(resultJson);
    }
    //}
  }
};

var decryptJson = (data, callback) => {
  var index = 0;
  let resultJson = {};
  //let iv = new Buffer(data.iv, 'hex');

  for (var key in data) {
    if (
      key == "CIN" ||
      key == "factoryStuffingLicNo" ||
      key == "GSTNo" ||
      key == "IEC" ||
      key == "address" ||
      key == "city" ||
      key == "landmark" ||
      key == "state" ||
      key == "zip" ||
      key == "zipcode" ||
      key == "fName" ||
      key == "lName" ||
      key == "contactNo" ||
      key == "designation" ||
      key == "additionalContactFName" ||
      key == "additionalContactLName" ||
      key == "address" ||
      key == "primaryContactFName" ||
      key == "primaryContactLName" ||
      key == "secondaryContactFName" ||
      key == "secondaryContactLName" ||
      key == "mobileNo" ||
      key == "additionalContactNo" ||
      key == "secondaryContactNo" ||
      key == "primaryContactNo" ||
      key == "additionalDesignation" ||
      key == "secondaryDesignation" ||
      key == "primaryDesignation" ||
      key == "gstno" ||
      key == "warehousePrimaryContactNo" ||
      key == "warehousePrimaryContactFName" ||
      key == "warehousePrimaryContactLName"
    ) {
      var decipher = crypto.createDecipher(
        algorithm,
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
      );
      //let decipher = crypto.createDecipheriv('aes-256-ctr', new Buffer(process.env.ENCRYPTION_KEY), iv);

      if (data.hasOwnProperty(key)) {
        //console.log(data[key]);
        if (data[key] != null) {
          var dec = decipher.update(data[key], "hex", "utf8");
          dec += decipher.final("utf8");
          resultJson[key] = dec;
          //resultJson[key] =  bcrypt.hashSync(data[key], null, null);
          //resultJson[key] = crypto.('pbkdf2',"test",data[key]);
          /*if(key != 'iv'){
            let encryptedText = new Buffer(data[key], 'hex');

            let decrypted = decipher.update(encryptedText);
            decrypted = Buffer.concat([decrypted, decipher.final()]);
            resultJson[key] = decrypted.toString();
        }*/
        } else {
          resultJson[key] = null;
        }
      }
    } else {
      resultJson[key] = data[key];
    }

    if (++index == Object.keys(data).length) {
      callback(resultJson);
    }
  }
};

//akib changes
module.exports.encryptData = (dataArray) => {
  /*dataArray = [{ test: "nishant", "value": "test", "test3": "nishant" }, {
        "test": "nishant",
        "value": "test",
        "test3": "nishant"
    }];*/

  return new Promise((resolve, reject) => {
    if (dataArray == undefined) {
      encrypt([dataArray], (result) => {
        resolve(result);
      });
    } else {
      encrypt(dataArray, (result) => {
        resolve(result);
      });
    }
  });
};

//sneha code
// module.exports.encryptData = (dataArray) => {
//     /*dataArray = [{ test: "nishant", "value": "test", "test3": "nishant" }, {
//         "test": "nishant",
//         "value": "test",
//         "test3": "nishant"
//     }];*/

//     return new Promise((resolve, reject) => {
//         if(typeof dataArray.length != "undefined" ){
//              encrypt(dataArray, (result) => {
//             resolve(result);
//         })
//         }
//         else{
//         encrypt([dataArray], (result) => {
//             resolve(result);
//         })
//     }
//     });
// };

module.exports.decryptData = (dataArray, callback) => {
  /* dataArray = [
        {
            "test": "4cc08ddf5a18a7",
            "value": "56cc8dc3",
            "test3": "4cc08ddf5a18a7"
        },
        {
            "test": "4cc08ddf5a18a7",
            "value": "56cc8dc3",
            "test3": "4cc08ddf5a18a7"
        }
    ];*/
  return new Promise((resolve, reject) => {
    decrypt(dataArray, (result) => {
      resolve(result);
    });
  });
};
