var express = require("express");
var router = express.Router();
var userservice = require("../service/UserService");

router.post("/adduser", (req, res, next) => {
  userservice
    .IsuserExists(req.body.email)
    .then((result) => {
      userservice
        .adduserdata(req.body)
        .then((result) => {
          res.json({
            status_code: 200,
            message: "User added sucessfull!",
            data: result,
          });
        })
        .catch((err) => {
          res.status(400).json({ message: "Error occured", data: err });
        });
    })
    .catch((err) => {
      res.status(400).json({ message: err.message });
    });
});

router.get("/getuserdata", (req, res, next) => {
  userservice
    .getuserdatainfo(req.query.Page_no)
    .then((result) => {
      res.json({ status: 200, message: "User list", data: result });
    })
    .catch((err) => {
      res.status(400).json({ message: "Error occured", data: err });
    });
});

router.get("/getuserdataByid", (req, res, next) => {
  userservice
    .getuserdataByid(req.query.id)
    .then((result) => {
      res.json({ status: 200, message: "User list", data: result });
    })
    .catch((err) => {
      res.status(400).json({ message: "Error occured", data: err });
    });
});

router.post("/updateuserlist", (req, res, next) => {
  userservice
    .updateuserlist(
      req.body.fname,
      req.body.lname,
      req.body.email,
      req.body.password
    )
    .than((result) => {
      res.json({
        status: 200,
        message: "User updeted succesfull !",
        data: result,
      });
    })
    .catch((err) => {
      res.status(400).json({ message: "Error Occourd", data: err });
    });
});

router.delete("/deleteuser", (req, res, next) => {
  userservice
    .deleteuser(req.query.id)
    .then((result) => {
      res.json({
        status: 200,
        message: "User deleted successfully !",
        data: result,
      });
    })
    .catch((err) => {
      res.status(400).json({ message: "Error Occourd", data: err });
    });
});

module.exports = router;
