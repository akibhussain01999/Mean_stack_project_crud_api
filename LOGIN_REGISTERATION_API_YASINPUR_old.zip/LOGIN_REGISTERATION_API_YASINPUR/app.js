var express = require("express");
var app = express();
var port = 3000;

require("./lib/config");

const cors = require("cors");
app.use(cors());

var bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var users = require("./route/User");
app.use("/users", users);

app.listen(port, () => {
  console.log(`app is running on port ${port}`);
});
